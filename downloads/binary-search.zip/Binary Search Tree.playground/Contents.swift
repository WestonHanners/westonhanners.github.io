//: Playground - noun: a place where people can play

import UIKit

class Leaf {
    var left: Leaf?
    var right: Leaf?
    var data: Int = 0

    init(fromData data: Int) {
        self.data = data
    }

    func searchTree(data: Int) -> Bool {
        if data == self.data {
            return true
        } else if data < self.data {
            if let left = self.left {
                return left.searchTree(data: data)
            } else {
                return false
            }
        } else {
            if let right = self.right {
                return right.searchTree(data: data)
            } else {
                return false
            }
        }
    }

    func insert(data: Int) -> Bool {
        if data == self.data {
            return false
        } else if data < self.data {
            if let left = self.left {
                return left.insert(data: data)
            } else {
                self.left = Leaf(fromData: data)
                return true
            }
        } else {
            if let right = self.right {
                return right.insert(data: data)
            } else {
                self.right = Leaf(fromData: data)
                return true
            }
        }
    }
}

var root = Leaf(fromData: 0)

for iteration in 0..<200 {
    root.insert(data: Int(arc4random_uniform(2000)))
}

root.searchTree(data: 2)
root.searchTree(data: 5)
root.searchTree(data: 20)
root.searchTree(data: 154)
