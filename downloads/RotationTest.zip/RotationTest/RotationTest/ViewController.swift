//
//  ViewController.swift
//  RotationTest
//
//  Created by Weston Hanners on 11/18/15.
//  Copyright (c) 2015 Weston Hanners. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  override func supportedInterfaceOrientations() -> Int {
    return Int(UIInterfaceOrientationMask.Portrait.rawValue)
  }

}

