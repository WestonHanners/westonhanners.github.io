//
//  LandscapeViewController.swift
//  RotationTest
//
//  Created by Weston Hanners on 11/18/15.
//  Copyright (c) 2015 Weston Hanners. All rights reserved.
//

import UIKit

class LandscapeViewController: UIViewController {
  
  override func supportedInterfaceOrientations() -> Int {
    return Int(UIInterfaceOrientationMask.Landscape.rawValue)
  }
  
}
