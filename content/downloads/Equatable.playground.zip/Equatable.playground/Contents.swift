import Foundation


func ==(lhs: Person, rhs: Person) -> Bool {
    return lhs.isEqual(rhs)
}

func ==(lhs: Employee, rhs: Employee) -> Bool {
    return lhs.isEqual(rhs)
}

class Person: Equatable {

    var name: String = "Bob"

    func isEqual(person: Person) -> Bool {
        return self.name == person.name
    }
}

class Employee: Person {

    var position: String = "Manager"

    func isEqual(person: Employee) -> Bool {
        var match = super.isEqual(person)

        match = match && self.position == person.position

        return match
    }

}

var person = Employee()
person.name = "Bill"
person.position = "Worker"


var person2 = Employee()
person2.name = "Bill"
person2.position = "Manager"

var person3 = Employee()
person3.name = "Bob"
person3.position = "Manager"

person == person2
person2 == person3
person == person3