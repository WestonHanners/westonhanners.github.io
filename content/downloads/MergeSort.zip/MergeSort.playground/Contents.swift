import Foundation

let data = [1,6,3,7,4,3,7,3,8,9,4,2,6,5,1]

func mergeSort(data: [Int]) -> [Int] {
    if data.count <= 1 {
        return data
    }

    let mid = data.count / 2

    let left = mergeSort(data: Array(data[0..<mid]))
    let right = mergeSort(data: Array(data[mid..<data.count]))

    return merge(left: left, right: right)
}

func merge(left: [Int], right: [Int]) -> [Int] {
    var left = left
    var right = right
    var result: [Int] = []

    while left.count > 0 && right.count > 0 {
        if left.first! < right.first! {
            result.append(left.removeFirst())
        } else {
            result.append(right.removeFirst() )
        }
    }

    while left.count > 0 {
        result.append(left.removeFirst())
    }

    while right.count > 0 {
        result.append(right.removeFirst())
    }

    return result
}

mergeSort(data: data)
