import Foundation

precedencegroup AssignmentPrecedence {
    associativity: right
}

infix operator ?= : AssignmentPrecedence

func ?=<T>(left: inout T, right: T?) {
    if let value = right {
        left = value
    }
}

func ?=<T>(left: inout T?, right: T?) {
    if let value = right {
        left = value
    }
}

var testValue: String?
var myValue: String = "old value"
print(myValue)

// test after assigning a value
testValue = "Hello"

myValue ?= testValue
print(myValue)

// Test after assigning nil
testValue = nil

myValue ?= testValue
print(myValue)
