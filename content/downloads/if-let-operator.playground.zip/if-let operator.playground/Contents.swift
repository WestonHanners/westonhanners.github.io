import Foundation

infix operator ||= { associativity right precedence 90 }

func ||=<T>(inout left: T, right: T?) {
    if let value = right {
        left = value
    }
}

// Function for assigning to optionals
func ||=<T>(inout left: T?, right: T?) {
    if let value = right {
        left = value
    }
}

let google = NSURL(string: "www.google.com")
let yahoo = NSURL(string: "www.yahoo.com")

// Good URL to start
var testURL: NSURL = yahoo!

// Failing URL
var url = NSURL(string: "\\/http")

// Another Failing URL
var straightUpNil: NSURL?

assert(testURL == yahoo)

testURL ||= url

// We want to keep initial value here
assert(testURL == yahoo)

testURL ||= google

// This one should have taken the new value
assert(testURL == google)

testURL ||= straightUpNil

// One more test to make sure
assert(testURL == google)
