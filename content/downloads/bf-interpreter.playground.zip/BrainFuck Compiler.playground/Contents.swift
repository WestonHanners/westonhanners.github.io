import Foundation

func parseBF(code: String, input: String = "") {
    
    if code.isEmpty {
        print("Empty Program")
        return
    }
    
    // BrainFuck Machine Initalization
    var bfMemory = Array<UInt32>.init(repeating: 0, count: 30000)
    var bfPointer = 0
    var inputPointer = 0
    var commandPointer = 0
    
    let commandArray = Array(code.characters)
    mainLoop: repeat {
        
        // Get the next command
        let command = commandArray[commandPointer]
        
        // Error handling
        if bfPointer < 0 || bfPointer > bfMemory.count - 1 {
            print("ERROR: \"\(command)\" at line \(commandPointer), Invalid Memory Location")
            break mainLoop
        }
        
        if commandPointer < 0 || commandPointer > commandArray.count {
            print("ERROR: \"\(command)\" at line \(commandPointer), Invalid Command Location")
            break mainLoop
        }
        
        // Process Commands
        switch command {
        case ">":
            bfPointer+=1
        case "<":
            bfPointer-=1
        case "+":
            if bfMemory[bfPointer] == 255 {
                bfMemory[bfPointer] = 0
            } else {
                bfMemory[bfPointer]+=1
            }
        case "-":
            if bfMemory[bfPointer] == 0 {
                bfMemory[bfPointer] = 255
            } else {
                bfMemory[bfPointer]-=1
            }
        case ".":
            print(bfMemory[bfPointer], terminator: "")
        case "_":
            print("\(UnicodeScalar(bfMemory[bfPointer])!)", terminator: "")
        case ",":
            if input.isEmpty {
                print("ERROR: \"\(command)\" at line \(commandPointer), Input is Empty")
                break mainLoop
            }
            
            if inputPointer > input.unicodeScalars.count {
                break mainLoop
            }
            
            bfMemory[bfPointer] = input.unicodeScalars[input.unicodeScalars.index(input.unicodeScalars.startIndex, offsetBy: inputPointer)].value
            inputPointer+=1
        case "[":
            break
        case "]":
            if bfMemory[bfPointer] != 0 {
                var nestLevel = 0
                findLoop: repeat {
                    commandPointer-=1
                    if commandArray[commandPointer] == "[" {
                        if nestLevel == 0 {
                            break
                        } else {
                            nestLevel-=1
                        }
                    } else if commandArray[commandPointer] == "]" {
                        nestLevel+=1
                    }
                } while true
                continue
            }
        default:
            print("ERROR: \"\(command)\" at line \(commandPointer), Not Implemented")
            break mainLoop
        }
        
        // Adjust commandPointer
        commandPointer+=1
    } while commandPointer < code.characters.count
}

parseBF(code: "++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]>>_>---_+++++++__+++_>>_<-_<_+++_------_--------_>>+_>++_", input: "")
