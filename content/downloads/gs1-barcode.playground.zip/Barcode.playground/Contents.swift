import PlaygroundSupport
import Foundation
import UIKit
import CoreImage

struct GS1Barcode {
    
    let FNC1 = "\u{1D}"
    let data: String
    let gtin: String
    let expiration: Date
    let lot: String
    var image: UIImage?
    var gpn: String {
        return "G\(gtin.substring(from: gtin.index(gtin.endIndex, offsetBy: -6)))"
    }
    
    init(gtin: String, expiration: Date, lot: String) {
        assert(gtin.characters.count == 14)
        self.gtin = gtin
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYMMdd"
        let dateString = dateFormatter.string(from: expiration)
        self.expiration = expiration
        
        assert(dateString.characters.count == 6)
        
        self.lot = lot
        
        data = "01\(gtin)17\(dateString)\(FNC1)10\(lot)"
        image = barcodeWithCode(code: data)
    }
    
    private func barcodeWithCode(code: String) -> UIImage? {
        if let image = filterWithCode(code: code)?.outputImage {
            return UIImage(ciImage: image, scale: 2, orientation: .up)
        }
        
        return nil
    }
    
    private func filterWithCode(code: String) -> CIFilter? {
        if let filter = CIFilter(name: "CICode128BarcodeGenerator") {
            let data = code.data(using: String.Encoding.utf8, allowLossyConversion: false)!
            filter.setValue(data, forKey: "inputMessage")
            
            return filter
        }
        return nil
    }
}

let barcode = GS1Barcode(gtin: "00375926123456", expiration: Date(), lot: "1234567")

let imageView = UIImageView(image: barcode.image)
imageView.frame = CGRect(x: 0, y: 0, width: 583, height: 92)
PlaygroundPage.current.liveView = imageView